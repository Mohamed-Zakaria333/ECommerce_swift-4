

import UIKit

@IBDesignable
class My_TXT: UItextField{

    @IBInspectable var cornerRadius: CGFloat = 0.0 {
        didSet {
        
        }
    }

}
