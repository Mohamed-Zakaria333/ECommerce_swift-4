//
//  collection_cell.swift
//  project
//
//  Created by MZ333 on 11/22/18.
//  Copyright © 2018 MZ333. All rights reserved.
//

import UIKit

class collection_cell: UICollectionViewCell {
    
    @IBOutlet var likeBTN: UIButton!;
    @IBOutlet var ADDBTN: UIButton!;
    @IBOutlet var ReviewBTN: UIButton!;
    @IBOutlet var Prodname: UILabel!;
    @IBOutlet var ProdIMG: UIImageView!;

    
    
    
    
    override func awakeFromNib() {
        super.awakeFromNib()
        
        
    }

    
    
  }
