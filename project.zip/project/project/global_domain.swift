//
//  global_domain.swift
//  project
//
//  Created by MZ333 on 11/21/18.
//  Copyright © 2018 MZ333. All rights reserved.
//

import Foundation

 struct flaging
    {
       static var bol_flag = false
    }

    
    
    
    
    

